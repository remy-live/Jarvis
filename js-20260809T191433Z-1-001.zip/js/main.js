import { Display } from './core/Display.js';
import { InputSystem } from './core/InputSystem.js';
import { Engine } from './core/Engine.js';
import { Header } from './core/Header.js';
//import { MenuVortex } from '../games/MenuVortex.js';
// --- 1. IMPORTS DES JEUX ---
// Note : On importe { MenuHub } spécifiquement pour pouvoir le lancer au démarrage
//import { MenuHub } from './games/MenuHub.js';
//import { MenuSketch } from './games/MenuSketch.js';
//import { MenuPaper } from './games/MenuPaper.js';
import { MenuHolo } from './games/MenuHolo.js';

// Les autres jeux sont importés pour s'enregistrer dans le Registry
//import './games/CalibrationTool.js';
import './games/NeonBrickBattle.js';
// import './games/SquirrelGame.js';
import './games/NutsGame.js';
import './games/NeonInvaders.js';
import './games/FlappySquat.js';
import './games/FlappySquat.js';
import './games/FruitBlade.js';
import './games/ShurikenShowdown.js';

// import './games/PongGame.js'; // Tu peux décommenter si tu as adapté Pong au nouveau système
// import './games/SpaceInvaders.js';

class JarvisArcade {
    constructor() {
        // UI de chargement HTML
        this.statusElement = document.getElementById('status-text');
        this.loadingBar = document.getElementById('loading-bar');
        
        // Démarrage de la séquence
        this.init();
    }

    async init() {
        try {
            // ÉTAPE 1 : DISPLAY
            this.updateStatus("INITIALISATION DU DUAL-CANVAS...", 10);
            this.display = new Display();

            // ÉTAPE 2 : IA & INPUTS (V2)
            this.updateStatus("BOOT NEURAL ENGINE V2...", 30);
            this.inputs = new InputSystem();
            
            // On configure un lissage par défaut agréable pour le menu
            this.inputs.setSmoothing(0.1); 
            
            // Chargement lourd (MediaPipe)
            await this.inputs.initialize();

            // ÉTAPE 3 : MOTEUR
            this.updateStatus("LANCEMENT DU MOTEUR...", 90);
            this.engine = new Engine(this.display, this.inputs);

            // ÉTAPE 4 : DÉMARRAGE DU HUB
            this.updateStatus("SYSTÈME PRÊT", 100);
            
          //  console.log("👉 MAIN: Lancement du Hub 3D");
            
            // NOUVEAU : On utilise la méthode loadGame avec le MenuHub
            this.engine.loadGame(MenuHolo);

            // Lancement de la boucle de rendu (attente caméra)
            this.boot();

        } catch (error) {
            console.error("CRITICAL BOOT ERROR:", error);
            if (this.statusElement) {
                this.statusElement.innerText = "ERREUR SYSTÈME : " + error.message;
                this.statusElement.style.color = "#ff0055";
            }
            alert("Erreur critique : Vérifiez la console (F12)");
        }
    }

    updateStatus(text, progress) {
        if (this.statusElement) this.statusElement.innerText = text;
        if (this.loadingBar) this.loadingBar.style.width = `${progress}%`;
    }

    boot() {
        // On attend que la webcam envoie vraiment des images pour éviter l'écran noir
        const checkVideo = setInterval(() => {
            // Vérifie si l'InputSystem a bien démarré la vidéo
            if (this.inputs.video && this.inputs.video.readyState >= 2) { 
                clearInterval(checkVideo);
                
                // Animation de disparition de l'overlay
                const bootScreen = document.getElementById('boot-screen'); // Ou 'start-overlay' selon ton HTML
                if (bootScreen) {
                    bootScreen.style.transition = "opacity 0.8s";
                    bootScreen.style.opacity = '0';
                    setTimeout(() => {
                        bootScreen.style.display = 'none';
                        // C'est parti !
                        this.engine.start(); 
                    }, 800);
                } else {
                    this.engine.start();
                }
            }
        }, 100);
    }
}

// Point d'entrée
window.onload = () => new JarvisArcade();