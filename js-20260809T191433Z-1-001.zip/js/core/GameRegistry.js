

class GameRegistry {
    constructor() {
        this.games = [];
    }

    /**
     * @param {string} id - L'identifiant unique (ex: 'game_nuts')
     * @param {string} name - Le nom affiché (ex: 'NOISETTES')
     * @param {class} gameClass - La classe (Le plan de construction)
     * @param {string} color - La couleur (facultatif)
     */
    register(id, name, gameClass, color = '#ffffff') {
        console.log(`📝 REGISTRY: Inscription de [${id}] -> ${name}`);
        
        // On stocke tout dans un objet propre
        this.games.push({
            id: id,          // L'ID est maintenant accessible ici !
            name: name,
            class: gameClass,
            color: color
        });
    }

    // Récupère la classe en cherchant par ID
    get(identifier) {
        const found = this.games.find(g => g.id === identifier);
        return found ? found.class : null;
    }

    getAll() {
        return this.games;
    }
}

export const Registry = new GameRegistry();