export class Header {
    constructor(engine) {
        this.engine = engine;
        this.dom = null;
        this.playerCount = 1; 
        this.isMuted = false;
        
        this.init();
    }

    init() {
        // 1. CRÉATION HTML
        this.dom = document.createElement('div');
        this.dom.id = 'ui-header';
        this.dom.className = 'header-overlay'; // Nouvelle classe CSS
        
        this.dom.innerHTML = `
            <div class="header-group left">
                <button id="btn-quit" class="btn-retro red" style="display:none;">⬅ MENU</button>
            </div>

            <div class="header-group center">
                <div id="player-switch" class="player-switch">
                    <div class="switch-opt active" data-val="1">1 JOUEUR</div>
                    <div class="switch-opt" data-val="2">2 JOUEURS</div>
                </div>
            </div>

            <div class="header-group right">
                <button id="btn-sound" class="btn-round">🔊</button>
            </div>
        `;
        document.body.appendChild(this.dom);

        // 2. STYLES CSS INJECTÉS (Le secret est ici)
        const style = document.createElement('style');
        style.innerHTML = `
            /* LE CONTENEUR PRINCIPAL : INVISIBLE ET INTANGIBLE */
            .header-overlay {
                position: absolute;
                top: 0; left: 0; width: 100%;
                height: 100px; /* Hauteur de la zone, mais transparente */
                display: flex; justify-content: space-between; align-items: flex-start;
                padding: 20px 30px;
                box-sizing: border-box;
                z-index: 1000; /* Au-dessus de tout */
                
                background: transparent; /* Fond invisible */
                pointer-events: none;    /* MAGIE : Les clics traversent le vide ! */
            }

            /* LES GROUPES D'INTERFACE : DOIVENT CAPTURER LES CLICS */
            .header-group {
                pointer-events: auto; /* On réactive les clics sur les boutons */
            }

            /* STYLE BOUTON RETRO (QUITTER) */
            .btn-retro {
                font-family: 'Orbitron', sans-serif; font-weight: bold;
                border: 2px solid white; border-radius: 8px;
                padding: 10px 20px; cursor: pointer;
                color: white; text-transform: uppercase;
                box-shadow: 0 4px 0 rgba(0,0,0,0.5);
                transition: transform 0.1s;
            }
            .btn-retro:active { transform: translateY(4px); box-shadow: none; }
            .btn-retro.red { background: #e74c3c; }
            .btn-retro.red:hover { background: #ff6b6b; }

            /* STYLE BOUTON ROND (SON) */
            .btn-round {
                width: 50px; height: 50px; border-radius: 50%;
                border: 2px solid white; background: rgba(0,0,0,0.5);
                color: white; font-size: 24px; cursor: pointer;
                display: flex; align-items: center; justify-content: center;
                transition: transform 0.2s, background 0.2s;
            }
            .btn-round:hover { transform: scale(1.1); background: rgba(0,0,0,0.8); }

            /* STYLE SWITCH JOUEURS */
            .player-switch {
                display: flex; background: rgba(0,0,0,0.6);
                border: 2px solid white; border-radius: 25px; overflow: hidden;
            }
            .switch-opt {
                padding: 10px 20px; color: #bbb; cursor: pointer;
                font-family: sans-serif; font-weight: bold;
            }
            .switch-opt.active {
                background: #00ffff; color: #000;
                box-shadow: 0 0 15px #00ffff;
            }
        `;
        document.head.appendChild(style);

        // 3. LISTENERS
        this.bindEvents();
    }

    bindEvents() {
        // Son
        const btnSound = this.dom.querySelector('#btn-sound');
        if (btnSound) {
            btnSound.addEventListener('click', () => this.toggleSound());
        }

        // Quitter
        const btnQuit = this.dom.querySelector('#btn-quit');
        if (btnQuit) {
            btnQuit.addEventListener('click', () => this.engine.loadGame('menu_holo'));
        }

        // Switch
        this.dom.querySelectorAll('.switch-opt').forEach(opt => {
            opt.addEventListener('click', (e) => {
                const val = parseInt(e.target.dataset.val);
                this.setPlayerCount(val);
            });
        });
    }

    // --- LOGIQUE ---

    toggleSound() {
        this.isMuted = !this.isMuted;
        const btn = this.dom.querySelector('#btn-sound');
        if (btn) btn.textContent = this.isMuted ? '🔇' : '🔊';

        if (this.engine && this.engine.toggleAudio) {
            this.engine.toggleAudio(this.isMuted);
        }
    }

    setMode(isMenu) {
        const switchDiv = this.dom.querySelector('#player-switch');
        const quitBtn = this.dom.querySelector('#btn-quit');

        if (isMenu) {
            // MODE MENU : On montre le switch, on cache le retour
            if(switchDiv) switchDiv.style.display = 'flex';
            if(quitBtn) quitBtn.style.display = 'none';
        } else {
            // MODE JEU : On cache le switch, on montre le retour
            if(switchDiv) switchDiv.style.display = 'none';
            if(quitBtn) quitBtn.style.display = 'block';
        }
    }

    setPlayerCount(count) {
        this.playerCount = count;
        this.dom.querySelectorAll('.switch-opt').forEach(opt => {
            if(parseInt(opt.dataset.val) === count) opt.classList.add('active');
            else opt.classList.remove('active');
        });
        if (this.engine) this.engine.config = { ...this.engine.config, playerCount: count };
    }
}