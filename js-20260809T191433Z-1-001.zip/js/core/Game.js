export class Game {
    constructor(engine) {
        this.engine = engine;
    }

    /**
     * Configure le jeu au démarrage
     * @param {object} options
     * @param {string} options.cameraMode - 'vignette' (défaut), 'fullscreen', 'hidden'
     * @param {boolean} options.face - Activer le tracking visage ? (défaut: false)
     * @param {boolean} options.pose - Activer le tracking corps ? (défaut: false)
     */
    setup(options = {}) {
        const inputs = this.engine.inputs;

        // 1. Config Caméra
        const mode = options.cameraMode || 'vignette';
        inputs.setCameraMode(mode);

        // 2. Config IA (Optimisation)
        inputs.setActiveTrackers({
            face: options.face || false,
            pose: options.pose || false
        });
    }

    // Méthodes vides par défaut, à surcharger par les jeux
    enter() {}
    update(dt) {}
    render(display) {}
    exit() {}
}