import * as THREE from 'three';
import { AudioManager } from './AudioManager.js';
import { Header } from './Header.js';
import { Registry } from './GameRegistry.js';

export class Engine {
    constructor(display, inputSystem) {
        this.display = display;
        this.inputs = inputSystem;
        this.header = new Header(this);
        this.registry = Registry;

        this.isRunning = false;
        this.currentState = null; 
        
        this.audio = new AudioManager();
        this.clock = new THREE.Clock();

        // Config Dwell Click
        this.dwellTime = 1200; 

        // Stockage des curseurs
        this.cursors = {}; 

        window.addEventListener('keydown', (e) => {
            if (e.key.toLowerCase() === 'm') this.loadGame('menu_paper'); 
        });
    }

    // Plus besoin de initCursorStyles() ! Tout est dans le CSS.

    getOrCreateCursor(id) {
        if (this.cursors[id]) return this.cursors[id];

        const cursorDiv = document.createElement('div');
        cursorDiv.className = 'virtual-cursor';
        cursorDiv.id = `cursor-p${id}`;
        
        // C'est ici qu'on définit la couleur via la variable CSS
        const color = id === 0 ? '#00ffff' : '#ff00ff';
        cursorDiv.style.setProperty('--cursor-color', color);

        // HTML épuré (les styles sont dans le CSS)
        cursorDiv.innerHTML = `
            <div class="cursor-scaler">
                <svg class="progress-ring" width="60" height="60" viewBox="0 0 60 60">
                   <circle class="ring-bg" cx="30" cy="30" r="22"/>
                   <circle class="ring-progress" cx="30" cy="30" r="22"/>
                </svg>
                <div class="cursor-dot"></div>
            </div>
        `;
        document.body.appendChild(cursorDiv);

        this.cursors[id] = {
            el: cursorDiv,
            ring: cursorDiv.querySelector('.ring-progress'),
            hoverStartTime: 0,
            hoveredElement: null,
            hasTriggered: false
        };

        return this.cursors[id];
    }

    start() {
        this.isRunning = true;
        requestAnimationFrame((t) => this.loop(t));
    }

    loadGame(gameIdentifier) {
        if (this.currentState && this.currentState.exit) this.currentState.exit();
        this.display.reset();

        let PotentialGame = null;
        if (typeof gameIdentifier === 'function') PotentialGame = gameIdentifier;
        else if (typeof gameIdentifier === 'string') PotentialGame = this.registry.get(gameIdentifier);
  
        const GameClass = (PotentialGame && PotentialGame.class) ? PotentialGame.class : PotentialGame;

        if (GameClass) {
            try {
                this.currentState = new GameClass(this);
                if (this.currentState.enter) {
                   const isMenu = this.currentState.isMenu === true;
                   if (this.header) this.header.setMode(isMenu);
                   this.currentState.enter();
                }
                console.log(`✅ ENGINE: Jeu démarré : ${GameClass.name}`);
            } catch (error) {
                console.error(`❌ CRASH ENGINE:`, error);
            }
        } else {
            console.error(`⚠️ Jeu introuvable :`, gameIdentifier);
        }
    }

    updateVirtualCursor() {
        const players = this.inputs.players;
        const now = Date.now();

        [0, 1].forEach(playerId => {
            const player = players[playerId];
            const cursor = this.getOrCreateCursor(playerId);

            if (!player || !player.detected) {
                cursor.el.style.display = 'none';
                this.resetDwell(cursor);
                return;
            }

            cursor.el.style.display = 'block';
            cursor.el.style.left = player.x + 'px';
            cursor.el.style.top = player.y + 'px';

            const interactives = document.querySelectorAll('#ui-header button, #ui-header .switch-opt, .interactive');
            let newHoveredElement = null;

            interactives.forEach(el => {
                const rect = el.getBoundingClientRect();
                if (player.x >= rect.left && player.x <= rect.right &&
                    player.y >= rect.top && player.y <= rect.bottom) {
                    newHoveredElement = el;
                }
            });

            if (newHoveredElement) {
                if (cursor.hoveredElement !== newHoveredElement) {
                    cursor.hoveredElement = newHoveredElement;
                    cursor.hoverStartTime = now;
                    cursor.hasTriggered = false;
                    
                    // On utilise les classes CSS pour l'animation
                    cursor.el.classList.add('cursor-locked');
                    if (this.playSound) this.playSound('hover');
                }

                if (!cursor.hasTriggered) {
                    const elapsed = now - cursor.hoverStartTime;
                    const progress = Math.min(1, elapsed / this.dwellTime); 
                    
                    const offset = 138 - (progress * 138);
                    if(cursor.ring) cursor.ring.style.strokeDashoffset = offset;

                    if (progress >= 1) {
                        this.triggerClick(cursor, newHoveredElement);
                    }
                }
            } else {
                this.resetDwell(cursor);
            }
        });
    }

    resetDwell(cursor) {
        cursor.hoveredElement = null;
        cursor.hasTriggered = false;
        // On retire les classes d'état
        cursor.el.classList.remove('cursor-locked');
        cursor.el.classList.remove('cursor-clicked');
        if (cursor.ring) cursor.ring.style.strokeDashoffset = 138; 
    }

    triggerClick(cursor, element) {
        cursor.hasTriggered = true; 
        
        element.click(); 
        if (this.playSound) this.playSound('select');

        // On ajoute la classe CSS pour le flash blanc
        cursor.el.classList.add('cursor-clicked');
        
        setTimeout(() => {
            // On retire la classe après le flash
            cursor.el.classList.remove('cursor-clicked');
            this.resetDwell(cursor); 
        }, 300);
    }

    playSound(type) {
        if (window.Howler && window.Howler._muted) return;
        if (!this.audioCtx) this.audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        if (this.audioCtx.state === 'suspended') this.audioCtx.resume();

        const osc = this.audioCtx.createOscillator();
        const gainNode = this.audioCtx.createGain();
        osc.connect(gainNode);
        gainNode.connect(this.audioCtx.destination);
        const now = this.audioCtx.currentTime;

        if (type === 'select') {
            osc.type = 'triangle';
            osc.frequency.setValueAtTime(800, now);
            gainNode.gain.setValueAtTime(0.1, now);
            gainNode.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
            osc.start(now);
            osc.stop(now + 0.15);
        } else if (type === 'hover') {
            osc.type = 'sine';
            osc.frequency.setValueAtTime(400, now);
            gainNode.gain.setValueAtTime(0.03, now);
            gainNode.gain.linearRampToValueAtTime(0, now + 0.1);
            osc.start(now);
            osc.stop(now + 0.1);
        }
    }

    toggleAudio(isMuted) {
        if (window.Howler) {
            window.Howler.mute(isMuted);
        }
    }

    loop(timestamp) {
        if (!this.isRunning) return;
        const dt = this.clock.getDelta();

        this.inputs.update(timestamp, this.display);
        this.updateVirtualCursor();
        
        if (this.currentState) {
            if (this.currentState.update) this.currentState.update(dt);
            if (this.currentState.render) this.currentState.render(this.display);
        }
        this.display.done();
        requestAnimationFrame((t) => this.loop(t));
    }
}