import * as THREE from 'three';

export class Display {
    constructor() {
        // 1. Récupération des Toiles (Canvas)
        this.threeCanvas = document.getElementById('three-canvas');   // Pour la 3D
        this.uiCanvas = document.getElementById('ui-canvas');         // Pour la 2D (Score, Menu)
        this.ctx = this.uiCanvas.getContext('2d');
        this.gameLayer = document.getElementById('layer-2d');
      //  this.domLayer = this.gameLayer;  // Pour le nouveau MenuPaper
        this.bgLayer   = document.getElementById('background-picture');
        
        // Le canvas de debug (la petite vignette en bas à droite)
        this.feedbackCanvas = document.getElementById("feedback-canvas");
        this.feedbackCtx = this.feedbackCanvas.getContext("2d");

        
        // 2. Configuration Three.js (Moteur 3D)
        this.scene = new THREE.Scene();
        

        // Caméra par défaut (sera souvent remplacée par les Jeux eux-mêmes)
        const aspect = window.innerWidth / window.innerHeight;
        this.camera = new THREE.PerspectiveCamera(75, aspect, 0.1, 1000);
        this.camera.position.z = 5;

        this.renderer = new THREE.WebGLRenderer({
            canvas: this.threeCanvas,
            antialias: true, // Lisse les bords (moins d'effet escalier)
            alpha: true      // IMPORTANT : Fond transparent pour voir la vidéo derrière
        });

        // 3. Initialisation de la taille
        this.virtW = 0;
        this.virtH = 0;
        this.onResize(); // On appelle ça tout de suite pour régler la taille
        
        // On écoute si l'utilisateur change la taille de la fenêtre
        window.addEventListener('resize', () => this.onResize());
    }
    
    setBackground(cssValue) {
        if (this.bgLayer) {
            this.bgLayer.style.background = cssValue;
        }
    }

    reset() {
        // 1. Vider la scène 3D
      

        while(this.scene.children.length > 0){ 
        const object = this.scene.children[0];
        
        // IMPORTANT : Libérer la mémoire GPU
        if (object.geometry) object.geometry.dispose();
        if (object.material) {
            // Un mesh peut avoir un array de matériaux
            if (Array.isArray(object.material)) {
                object.material.forEach(mat => mat.dispose());
            } else {
                object.material.dispose();
            }
        }
        this.scene.remove(object); 
    }
        
        // 2. Vider le DOM 2D (Supprime le masque et les noisettes)
        if (this.gameLayer) {
            this.gameLayer.innerHTML = '';
            this.gameLayer.style = ''; // Reset des styles éventuels
        }

        // 3. Reset du fond par défaut
        this.setBackground('radial-gradient(circle, #222 0%, #000 100%)');

        // 4. Effacer le Canvas UI
        this.clear();
    }

    /**
     * Gère le redimensionnement de la fenêtre.
     * S'assure que le jeu prend toujours tout l'écran.
     */
    onResize() {
        const w = window.innerWidth;
        const h = window.innerHeight;
        
        // Mise à jour taille 3D
        this.renderer.setSize(w, h);
        if (this.camera.type === 'PerspectiveCamera') {
            this.camera.aspect = w / h;
            this.camera.updateProjectionMatrix();
        }
        
        // Mise à jour taille 2D
        this.uiCanvas.width = w;
        this.uiCanvas.height = h;

        // On stocke les dimensions pour que les jeux puissent s'en servir
        this.virtW = w;
        this.virtH = h;
    }

    /**
     * CONVERTISSEUR DE COORDONNÉES
     * Transforme les valeurs normalisées (0 à 1) venant de l'IA
     * en pixels réels sur l'écran (ex: 0.5 -> 960px).
     */
    toVirtual(x, y) {
        return { 
            x: x * this.virtW, 
            y: y * this.virtH 
        };
    }

    // Utile pour dessiner sur la petite vignette de debug
    toFeedback(x, y, canvas) {
        return {
            x: x * canvas.width, 
            y: y * canvas.height
        };
    }

    /**
     * DÉBUT DE FRAME
     * 1. Dessine la scène 3D
     * 2. Efface le canvas 2D pour qu'il soit propre
     */
    clear() {
        // Rendu 3D (Three.js)
        this.renderer.render(this.scene, this.camera);
        
        // Nettoyage 2D
        this.ctx.clearRect(0, 0, this.virtW, this.virtH);
    }

    /**
     * FIN DE FRAME
     * Sert juste de marqueur pour l'instant.
     * Utile si on veut rajouter des effets globaux plus tard.
     */
    done() {
        // Rien de spécial pour l'instant
    }
}