update(timestamp, display) {
        if (!this.isReady) return;

        this.resizeFeedbackCanvas();
        const ctx = this.feedbackCtx;
        const w = this.feedbackCanvas.width;
        const h = this.feedbackCanvas.height;

        // Préparation IA
        this.analysisCtx.drawImage(this.video, 0, 0, 640, 480);
        
        // Rendu Miroir
        ctx.save();
        ctx.translate(w, 0);
        ctx.scale(-1, 1);
        ctx.drawImage(this.video, 0, 0, w, h);
        ctx.restore();

        // 1. DÉTECTION DU CORPS (POSE)

        this.players = []; 

        let currentPose = null;
        this.pose = null;
        if (this.enablePose) {
            const poseResult = this.poseLandmarker.detectForVideo(this.analysisCanvas, timestamp);
            
            // CORRECTION IMPORTANTE ICI
            if (poseResult.landmarks && poseResult.landmarks.length > 0) {
                // 1. On récupère le tableau de points (0 à 1)
                const rawPose = poseResult.landmarks[0];

                // 2. PETITE ASTUCE : MIROIR (OPTIONNEL MAIS MIEUX)
                // MediaPipe donne X de gauche à droite. En miroir, on veut l'inverse.
                // On clone les points pour ne pas casser l'original et on inverse X.
                // (Note: Pour FlappySquat c'est inutile car on utilise que Y, mais utile pour d'autres jeux)
                this.pose = rawPose.map(p => ({
                    x: 1 - p.x, // Miroir horizontal
                    y: p.y,     // Y reste normal (0 haut, 1 bas)
                    z: p.z,
                    visibility: p.visibility
                }));

                // 3. On dessine (le drawPose gère déjà la conversion pixels pour l'affichage)
                this.drawPose(rawPose, display);
            }
        }

        // 2. DÉTECTION DU VISAGE (FACE)
        let currentFaceData = null;
        if (this.enableFace) {
        const faceResult = this.faceLandmarker.detectForVideo(this.analysisCanvas, timestamp);
        
        if (faceResult.faceLandmarks.length > 0) {
            const lm = faceResult.faceLandmarks[0];
            
            // --- A. Position Nez & Front ---
            const noseRaw = lm[1];
            const nosePos = display.toVirtual(1 - noseRaw.x, noseRaw.y);
            const foreheadRaw = lm[10];
            const foreheadPos = display.toVirtual(1 - foreheadRaw.x, foreheadRaw.y);

            // --- B. Bouche (Centre) ---
            const lipTop = lm[13];
            const lipBot = lm[14];
            const mouthX = (lipTop.x + lipBot.x) / 2;
            const mouthY = (lipTop.y + lipBot.y) / 2;
            const mouthPos = display.toVirtual(1 - mouthX, mouthY);

            // --- C. YEUX (Calcul de l'ouverture) ---
            // On mesure la distance verticale entre les paupières
            // Œil droit (Points 159 et 145) (Qui est l'oeil gauche du coup)
            const rightEyeDist = Math.abs(lm[159].y - lm[145].y);
            // Œil gauche (Points 386 et 374)
            const leftEyeDist = Math.abs(lm[386].y - lm[374].y);

            // Seuil de clignement (Threshold) : Si < 0.015, c'est fermé
            const blinkThresh = 0.015; 
            
            const upperLip = lm[13];
            const lowerLip = lm[14];
            
            // Distance brute normalisée
            const mouthDist = Math.hypot(upperLip.x - lowerLip.x, upperLip.y - lowerLip.y);
            // Inversion des yeux
            // On stocke ça dans currentFaceData
            currentFaceData = {
                nose: nosePos, 
                forehead: foreheadPos, 
                mouth: mouthPos,
                isRightEyeOpen: rightEyeDist > blinkThresh,
                isLeftEyeOpen: leftEyeDist> blinkThresh,
                mouthOpening: mouthDist 
            };

            this.drawFace(lm, display);
        }
       }

        // 3. DÉTECTION MAINS & ASSEMBLAGE (Version Renforcée)
        const handResult = this.handLandmarker.detectForVideo(this.analysisCanvas, timestamp);
        
        if (handResult.landmarks && handResult.landmarks.length > 0) {
            handResult.landmarks.forEach((landmarks, index) => {
                
                // --- CALCUL DES DONNÉES BRUTES ---
                
                // Index (Précision)
                const tip = landmarks[8];
                const indexRaw = display.toVirtual(1 - tip.x, tip.y);

                // Paume (Stabilité)
                const wrist = landmarks[0];
                const middleBase = landmarks[9];
                const palmX = (wrist.x + middleBase.x) / 2;
                const palmY = (wrist.y + middleBase.y) / 2;
                const palmRaw = display.toVirtual(1 - palmX, palmY);

                // Taille de la main (Distance Paume <-> Index pour le Z)
                const dx = palmRaw.x - indexRaw.x;
                const dy = palmRaw.y - indexRaw.y;
                const rawSize = Math.sqrt(dx*dx + dy*dy);

                // --- LISSAGE ET CALIBRATION ---
                
                // On lisse X et Y
                const smoothX = this._smoothValue(index, 'x', indexRaw.x);
                const smoothY = this._smoothValue(index, 'y', indexRaw.y);
                
                // On calcule et lisse Z
                const zVal = this.getCalibratedZ(rawSize);
                const smoothZ = this._smoothValue(index, 'z', zVal);
                
                const thumbTip = landmarks[4];
                const indexTip = landmarks[8];
                
                // Distance Euclidienne simple (en coordonnées normalisées 0-1)
                const pinchDist = Math.hypot(thumbTip.x - indexTip.x, thumbTip.y - indexTip.y);
                
                // Si la distance est très petite (< 0.05), on considère que ça "clique"
                const isPinching = pinchDist < 0.05;

                // --- CRÉATION DU JOUEUR OPTIMISÉ ---
                this.players.push({ 
                    id: index,
                    isClicking: isPinching,
                    x: smoothX,      
                    y: smoothY,
                    z: smoothZ,      
                    
                    // On garde les données brutes si un jeu en a besoin (ex: gestes rapides)
                    raw: { x: indexRaw.x, y: indexRaw.y, size: rawSize },

                    // Données spécifiques
                    indexTip: { x: smoothX, y: smoothY }, // Lissé
                    handCenter: palmRaw, // On laisse la paume brute pour l'instant
                    
                    // Injection Pose et Face (pour le joueur 1)
                    poseLandmarks: (index === 0) ? currentPose : null,
                    face: (index === 0) ? currentFaceData : null 
                });

                this.drawHand(landmarks, display); 
            });
        } 
       else if (currentPose || currentFaceData) {
    
          /*  let defaultX = 0.5, defaultY = 0.5;
            
            if (currentFaceData) {
                defaultX = currentFaceData.nose.x;
                defaultY = currentFaceData.nose.y;
            } else if (currentPose) {
                const nose = currentPose[0];
                const pos = display.toVirtual(1 - nose.x, nose.y);
                defaultX = pos.x;
                defaultY = pos.y;
            }  */

        

          /*  this.players.push({
                x: defaultX, y: defaultY, z: 0,
                id: 0, isBodyOnly: true,
                poseLandmarks: currentPose, face: currentFaceData
            });*/
            // Reset du lissage si on perd les mains pour éviter les bugs à la reprise
           // this.previousStates = {}; 
        }
          if (this.players.length > 0) {
            // On prend le premier joueur détecté
            this.hand = this.players[0];
           } else {
            // Personne détecté
            this.hand = null;
          }
        
            if (!this.hand) {
            // On peut simuler une main avec la souris (optionnel mais pratique)
            // this.hand = { indexTip: { x: this.mouse.x / window.innerWidth, y: this.mouse.y / window.innerHeight } };
            }
    }