export class GameOverModal {
    constructor(game) {
        this.game = game;
        this.dom = null;
        this.isVisible = false;
        
        this.savedGameConfig = null; // Pour se souvenir de la config du jeu
        this.onRetryCallback = null;

        this.init();
    }

    init() {
        this.dom = document.createElement('div');
        this.dom.id = 'gameover-modal';
        this.dom.className = 'modal-overlay';
        this.dom.style.display = 'none';

        this.dom.innerHTML = `
            <div class="modal-box">
                <h1 class="modal-title">GAME OVER</h1>
                <div class="modal-score" id="modal-score-text">SCORE: 0</div>
                <div class="modal-actions">
                    <button id="btn-retry" class="btn-modal interactive">REJOUER ↻</button>
                    <button id="btn-menu" class="btn-modal interactive">MENU 🏠</button>
                </div>
            </div>
        `;
        document.body.appendChild(this.dom);

        this.dom.querySelector('#btn-retry').addEventListener('click', () => this.retry());
        this.dom.querySelector('#btn-menu').addEventListener('click', () => this.quit());
    }

    show(scoreInfo, gameConfig, onRetry) {
        if (this.isVisible) return;
        this.isVisible = true;
        this.savedGameConfig = gameConfig;
        this.onRetryCallback = onRetry;

        // Mise à jour du texte
        const scoreDiv = this.dom.querySelector('#modal-score-text');
        if (typeof scoreInfo === 'object') {
            scoreDiv.innerHTML = `P1: <span style="color:#f1c40f">${scoreInfo.p1}</span> | P2: <span style="color:#e74c3c">${scoreInfo.p2}</span>`;
        } else {
            scoreDiv.innerText = `SCORE: ${scoreInfo}`;
        }

        // Affichage
        this.dom.style.display = 'flex';
        setTimeout(() => this.dom.classList.add('visible'), 10);

        // --- BASCULE INPUT : MODE "CURSEUR SEULEMENT" ---
        console.log("👉 MODAL: Activation Mains (Curseur), Désactivation Corps");
        this.game.inputs.setActiveTrackers({
            hands: true,  // OUI : On veut le curseur
            pose: false,  // NON : On ne joue plus
            face: false
        });
        
        // On augmente le lissage pour que le curseur soit facile à contrôler
        if(this.game.inputs.setSmoothing) this.game.inputs.setSmoothing(0.85);
    }

    hide() {
        this.isVisible = false;
        this.dom.classList.remove('visible');
        setTimeout(() => {
            this.dom.style.display = 'none';
        }, 300);
    }

    retry() {
        this.hide();

        // --- RESTAURATION INPUT : MODE "JEU" ---
        console.log("🏋️ MODAL: Retour au jeu (Restauration Config)");
        if (this.savedGameConfig) {
            this.game.inputs.setActiveTrackers(this.savedGameConfig);
        }
        
        // On remet le lissage standard
        if(this.game.inputs.setSmoothing) this.game.inputs.setSmoothing(0.75);

        if (this.onRetryCallback) this.onRetryCallback();
    }

    quit() {
        this.hide();
        this.game.engine.loadGame('menu_holo');
    }
}