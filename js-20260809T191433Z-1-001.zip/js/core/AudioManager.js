// core/AudioManager.js

export class AudioManager {
    constructor() {
        this.currentMusic = null;
        this.currentMusicPath = ""; 
        this.sfxBank = {};          
        this.globalCache = {};      
        this.isMuted = false;
        this.fadeTime = 1000;       
    }

    setupGameAudio(config) {
        if (!config) return;

        // 1. MUSIQUE
        if (config.music) {
            this._transitionMusic(config.music);
        }

        // 2. BRUITAGES (SFX)
        this.sfxBank = {}; 
        if (config.sfx) {
            for (const [id, path] of Object.entries(config.sfx)) {
                this.sfxBank[id] = this._getOrLoad(path, false);
            }
        }
    }

    playSFX(id) {
        if (this.isMuted) return;
        const sound = this.sfxBank[id];
        if (sound) {
            sound.play();
        } else {
            // Pas d'erreur fatale, juste un warning
            // console.warn(`⚠️ Bruitage '${id}' manquant.`);
        }
    }

    _transitionMusic(newPath) {
        if (this.currentMusicPath === newPath) return;

        // console.log(`🎵 Transition musique: ${newPath}`);

        if (this.currentMusic) {
            const old = this.currentMusic;
            old.fade(1, 0, this.fadeTime);
            old.once('fade', () => { old.stop(); });
        }

        const nextTrack = this._getOrLoad(newPath, true);
        
        if (!this.isMuted) {
            nextTrack.volume(0);
            nextTrack.play();
            nextTrack.fade(0, 0.5, this.fadeTime); 
        }

        this.currentMusic = nextTrack;
        this.currentMusicPath = newPath;
    }

    _getOrLoad(path, isMusic) {
        if (this.globalCache[path]) {
            return this.globalCache[path];
        }

        // On vérifie que Howler est bien chargé
        if (typeof Howl === 'undefined') {
            console.error("❌ ERREUR: Howler.js n'est pas inclus dans index.html !");
            return null;
        }

        const sound = new Howl({
            src: [path],
            html5: isMusic, 
            loop: isMusic,
            volume: isMusic ? 0.5 : 1.0
        });

        this.globalCache[path] = sound;
        return sound;
    }
}