import { HandLandmarker, PoseLandmarker, FaceLandmarker, FilesetResolver } from "./vision_bundle.js";

export class InputSystem {
    constructor() {
        // 1. Éléments DOM
        this.video = document.getElementById("webcam-video");
        this.feedbackCanvas = document.getElementById("feedback-canvas");
        this.feedbackCtx = this.feedbackCanvas.getContext("2d");

        // 2. Canvas invisible pour l'analyse IA
        this.analysisCanvas = document.createElement("canvas");
        this.analysisCanvas.width = 640;
        this.analysisCanvas.height = 480;
        this.analysisCtx = this.analysisCanvas.getContext("2d");

        // 3. État du système
        this.players = []; 
        this.isReady = false;
        this.enableFace = false;
        this.enablePose = false;

        // --- CONFIGURATION & MÉMOIRE ---
        this.smoothing = 0.75; 
        this.previousStates = {}; 
        this.calibration = this.loadCalibration();
        
        // --- OPTION FANTÔME ---
        this.useGhost = false; // Touche 'G' pour activer

        // Pour le curseur (legacy)
        this.hand = null;           
        this.mouse = { x: 0, y: 0 }; 

        // Capture souris + Raccourci G
        window.addEventListener('mousemove', (e) => {
            this.mouse.x = e.clientX;
            this.mouse.y = e.clientY;
        });

        window.addEventListener('keydown', (e) => {
            if (e.key.toLowerCase() === "v") this.toggleView();
            if (e.key.toLowerCase() === "g") {
                this.useGhost = !this.useGhost;
                console.log(`👻 MODE FANTÔME: ${this.useGhost ? "ACTIVÉ" : "DÉSACTIVÉ"}`);
            }
        });

        // 4. Gestion de la Vue
        this.feedbackCanvas.classList.add("view-vignette"); 
    }

    // --- A. GESTION PERSISTANCE & LISSAGE ---

    setSmoothing(val) {
        this.smoothing = Math.max(0.01, Math.min(1.0, val));
    }

    saveCalibration(data) {
        this.calibration = { ...this.calibration, ...data };
        localStorage.setItem("arcade_calibration", JSON.stringify(this.calibration));
        console.log("💾 InputSystem: Calibration sauvegardée !", this.calibration);
    }

    loadCalibration() {
        const data = localStorage.getItem("arcade_calibration");
        if (data) return JSON.parse(data);
        return {
            scaleX: 30, scaleY: 20, scaleZ: 40,
            offsetX: 0, offsetY: 0, offsetZ: 0,
            refSize: 0 
        };
    }

    _smoothValue(id, axis, targetVal) {
        if (!this.previousStates[id]) this.previousStates[id] = {};
        if (this.previousStates[id][axis] === undefined) {
            this.previousStates[id][axis] = targetVal;
            return targetVal;
        }
        const prev = this.previousStates[id][axis];
        const next = prev + (targetVal - prev) * this.smoothing;
        this.previousStates[id][axis] = next;
        return next;
    }

    // Calcul du Z (Profondeur) basé sur la taille de la main
    getCalibratedZ(currentSize) {
        if (this.calibration.refSize && this.calibration.refSize > 0) {
            const ratio = currentSize / this.calibration.refSize;
            return (ratio - 1) * this.calibration.scaleZ;
        }
        return 0;
    }

    // --- B. GESTION DE LA VUE ---

    toggleView() {
        const cl = this.feedbackCanvas.classList;
        if (cl.contains("view-vignette")) {
            cl.replace("view-vignette", "view-fullscreen");
        } else {
            cl.replace("view-fullscreen", "view-vignette");
        }
        this.feedbackCanvas.width = 1; 
    }

    resizeFeedbackCanvas() {
        if (this.feedbackCanvas.width !== this.feedbackCanvas.clientWidth || 
            this.feedbackCanvas.height !== this.feedbackCanvas.clientHeight) {
            this.feedbackCanvas.width = this.feedbackCanvas.clientWidth;
            this.feedbackCanvas.height = this.feedbackCanvas.clientHeight;
        }
    }

    setCameraMode(mode) {
        this.feedbackCanvas.classList.remove('view-vignette', 'view-fullscreen');
        this.feedbackCanvas.style.display = 'block'; 
        switch (mode) {
            case 'fullscreen': this.feedbackCanvas.classList.add('view-fullscreen'); break;
            case 'vignette': this.feedbackCanvas.classList.add('view-vignette'); break;
            case 'hidden': this.feedbackCanvas.style.display = 'none'; break;
        }
        this.resizeFeedbackCanvas();
    }

    setActiveTrackers(config) {
        this.enableFace = config.face || false;
        this.enablePose = config.pose || false;
        console.log(`⚙️ INPUTS: Config IA -> Face: ${this.enableFace}, Pose: ${this.enablePose}`);
    }

    // --- C. BOUCLE PRINCIPALE (UPDATE) ---

    update(timestamp, display) {
        if (!this.isReady) return;

        // 1. RENDU MIROIR
        this.resizeFeedbackCanvas();
        const ctx = this.feedbackCtx;
        const w = this.feedbackCanvas.width;
        const h = this.feedbackCanvas.height;

        this.analysisCtx.drawImage(this.video, 0, 0, 640, 480);
        ctx.save();
        ctx.translate(w, 0);
        ctx.scale(-1, 1);
        ctx.drawImage(this.video, 0, 0, w, h);
        
        if (this.useGhost) {
            ctx.fillStyle = "rgba(255, 0, 0, 0.5)";
            ctx.font = "20px Arial";
            ctx.scale(-1, 1); 
            ctx.fillText("👻 GHOST ON", -w + 10, 30);
        }
        ctx.restore();

        // 2. PRÉPARATION DES JOUEURS (SLOTS VIDES)
        // On initialise avec des valeurs par défaut pour éviter les crashs si on lit p.x
        const createEmptyPlayer = (id, defaultX) => ({
            id: id,
            detected: false,
            x: defaultX * display.virtW,
            y: 0.5 * display.virtH,
            z: 0,
            type: 'none',
            isClicking: false,
            
            // Propriétés Legacy (pour compatibilité anciens jeux)
            indexTip: { x: defaultX * display.virtW, y: 0.5 * display.virtH },
            handCenter: { x: defaultX * display.virtW, y: 0.5 * display.virtH },
            raw: { size: 0 },
            
            hand: null, 
            face: null, 
            pose: null,
            poseLandmarks: null
        });

        const p1 = createEmptyPlayer(0, 0.25);
        const p2 = createEmptyPlayer(1, 0.75);

        // --- A. DÉTECTION POSE ---
        if (this.enablePose) {
            const poseResult = this.poseLandmarker.detectForVideo(this.analysisCanvas, timestamp);
            if (poseResult.landmarks && poseResult.landmarks.length > 0) {
                poseResult.landmarks.forEach((lm) => {
                    this.drawPose(lm, display); 
                    
                    // Miroir horizontal des landmarks pour la cohérence
                    const mirroredLm = lm.map(p => ({ ...p, x: 1 - p.x }));

                    const nose = lm[0];
                    const screenXNormalized = 1 - nose.x; 
                    const pos = display.toVirtual(screenXNormalized, nose.y);

                    // TRI GAUCHE / DROITE
                    let target = (screenXNormalized < 0.5) ? p1 : p2;
                    
                    target.detected = true;
                    target.type = 'pose';
                    target.x = this._smoothValue(target.id, 'x', pos.x);
                    target.y = this._smoothValue(target.id, 'y', pos.y);
                    
                    target.pose = { raw: lm };
                    target.poseLandmarks = mirroredLm; // Legacy support
                });
            }
        }

        // --- B. DÉTECTION MAINS (Support complet Legacy) ---
        const handResult = this.handLandmarker.detectForVideo(this.analysisCanvas, timestamp);
        if (handResult.landmarks && handResult.landmarks.length > 0) {
            handResult.landmarks.forEach((lm) => {
                this.drawHand(lm, display);

                // --- 1. Calculs Géométriques ---
                const tip = lm[8];   // Bout de l'index
                const wrist = lm[0]; // Poignet
                const middle = lm[9]; // Base du majeur
                const thumb = lm[4]; // Pouce

                // Position écran (Index)
                const screenXNormalized = 1 - tip.x;
                const pos = display.toVirtual(screenXNormalized, tip.y);

                // Position Paume (Centre approximatif)
                const palmX = (wrist.x + middle.x) / 2;
                const palmY = (wrist.y + middle.y) / 2;
                const palmPos = display.toVirtual(1 - palmX, palmY);
                
                // Taille main (pour Z) - distance entre Paume et Index
                const dx = palmPos.x - pos.x;
                const dy = palmPos.y - pos.y;
                const rawSize = Math.sqrt(dx*dx + dy*dy);
                
                // Pinch / Click
                const pinchDist = Math.hypot(thumb.x - tip.x, thumb.y - tip.y);
                const isClicking = pinchDist < 0.05;

                // --- 2. Attribution Joueur ---
                let target = (screenXNormalized < 0.5) ? p1 : p2;
                
                // Si le joueur n'était pas encore détecté par la pose
                if (!target.detected) {
                    target.detected = true;
                    target.type = 'hand';
                }

                // --- 3. Mise à jour des Données (Legacy & New) ---
                // On lisse la position principale
                target.x = this._smoothValue(target.id, 'x', pos.x);
                target.y = this._smoothValue(target.id, 'y', pos.y);
                
                // Calcul du Z
                const zVal = this.getCalibratedZ(rawSize);
                target.z = this._smoothValue(target.id, 'z', zVal);

                target.isClicking = isClicking;
                
                // Structures de données pour les jeux
                target.hand = { raw: lm, x: pos.x, y: pos.y };
                target.indexTip = { x: target.x, y: target.y }; // Version lissée
                target.handCenter = palmPos;
                target.raw = { size: rawSize }; // Pour les jeux qui utilisent la taille
            });
        }

        // --- C. DÉTECTION VISAGE ---
        if (this.enableFace) {
            const faceResult = this.faceLandmarker.detectForVideo(this.analysisCanvas, timestamp);
            if (faceResult.faceLandmarks && faceResult.faceLandmarks.length > 0) {
                faceResult.faceLandmarks.forEach((lm) => {
                    this.drawFace(lm, display);

                    const nose = lm[1];
                    const screenXNormalized = 1 - nose.x;
                    const pos = display.toVirtual(screenXNormalized, nose.y);
                    const mouthDist = Math.hypot(lm[13].x - lm[14].x, lm[13].y - lm[14].y);

                    let target = (screenXNormalized < 0.5) ? p1 : p2;

                    if (!target.detected) {
                        target.detected = true;
                        target.type = 'face';
                        target.x = this._smoothValue(target.id, 'faceX', pos.x);
                        target.y = this._smoothValue(target.id, 'faceY', pos.y);
                    }
                    
                    target.face = { raw: lm, mouthOpen: mouthDist > 0.05, nose: pos };
                    if (target.type === 'face') target.isClicking = (mouthDist > 0.05);
                });
            }
        }

        // --- D. GESTION DU FANTÔME ---
        if (this.useGhost && p1.detected) {
            p2.detected = true;
            p2.type = p1.type;
            p2.isClicking = p1.isClicking;
            
            // Décalage pour le mettre à droite
            const ghostOffset = display.virtW * 0.5;
            p2.x = p1.x + ghostOffset;
            p2.y = p1.y;
            p2.z = p1.z;

            // Copie profonde des structures pour éviter les références partagées
            // (Simplifié ici par assignation directe car on ne modifie pas les sous-objets en général)
            if (p1.indexTip) p2.indexTip = { x: p1.indexTip.x + ghostOffset, y: p1.indexTip.y };
            if (p1.handCenter) p2.handCenter = { x: p1.handCenter.x + ghostOffset, y: p1.handCenter.y };
            p2.raw = p1.raw;
            p2.poseLandmarks = p1.poseLandmarks;
            p2.hand = p1.hand;
            p2.face = p1.face;
        }

        // 3. FINALISATION
        this.players = [p1, p2];
        this.hand = p1; // Pour le curseur UI

        if (display.updateCursor) {
            display.updateCursor(p1);
        }
    }

    // --- FONCTIONS DE DESSIN ---
    drawHand(landmarks, display) {
        const ctx = this.feedbackCtx;
        const canvas = this.feedbackCanvas;
        ctx.strokeStyle = "rgba(0, 255, 255, 0.9)"; 
        ctx.lineWidth = 3; ctx.lineCap = "round"; 
        ctx.shadowBlur = 15; ctx.shadowColor = "#00ffff";
        const connections = [[0, 1, 2, 3, 4], [0, 5, 6, 7, 8], [5, 9, 13, 17], [0, 17, 18, 19, 20], [9, 10, 11, 12], [13, 14, 15, 16]];
        connections.forEach(chain => {
            ctx.beginPath();
            for (let i = 0; i < chain.length - 1; i++) {
               const p1 = display.toFeedback(1 - landmarks[chain[i]].x, landmarks[chain[i]].y, canvas);
               const p2 = display.toFeedback(1 - landmarks[chain[i+1]].x, landmarks[chain[i+1]].y, canvas); 
               if (i === 0) ctx.moveTo(p1.x, p1.y); ctx.lineTo(p2.x, p2.y);
            }
            ctx.stroke();
        });
        ctx.shadowBlur = 0;
    }
    
    drawPose(landmarks, display) {
        const ctx = this.feedbackCtx;
        const canvas = this.feedbackCanvas;
        ctx.strokeStyle = "rgba(0, 255, 0, 0.5)"; ctx.lineWidth = 4; ctx.shadowBlur = 0;
        const connections = [[11,12],[11,23],[12,24],[23,24],[11,13],[13,15],[12,14],[14,16]];
        ctx.beginPath();
        connections.forEach(([i, j]) => {
            if(landmarks[i] && landmarks[j]) {
                const p1 = display.toFeedback(1 - landmarks[i].x, landmarks[i].y, canvas);
                const p2 = display.toFeedback(1 - landmarks[j].x, landmarks[j].y, canvas);
                ctx.moveTo(p1.x, p1.y); ctx.lineTo(p2.x, p2.y);
            }
        });
        ctx.stroke();
    }

    drawFace(landmarks, display) {
        const ctx = this.feedbackCtx;
        const canvas = this.feedbackCanvas;
        ctx.lineWidth = 1.5; ctx.shadowBlur = 8;
        const faceZones = {
            contour: { color: "rgba(0, 255, 255, 0.5)", shadow: "#00ffff", paths: [[10, 338, 297, 332, 284, 251, 389, 356, 454, 323, 361, 288, 397, 365, 379, 378, 400, 377, 152, 148, 176, 149, 150, 136, 172, 58, 132, 93, 234, 127, 162, 21, 54, 103, 67, 109, 10]] },
            eyebrows: { color: "rgba(255, 200, 0, 0.7)", shadow: "#ffcc00", paths: [[70, 63, 105, 66, 107, 55, 65, 52, 53, 46], [336, 296, 334, 293, 300, 276, 283, 282, 295, 285]] },
            eyes: { color: "rgba(100, 200, 255, 0.8)", shadow: "#64c8ff", paths: [[33, 246, 161, 160, 159, 158, 157, 173, 133, 155, 154, 153, 145, 144, 163, 7, 33], [263, 466, 388, 387, 386, 385, 384, 398, 362, 382, 381, 380, 374, 373, 390, 249, 263]] },
            nose: { color: "rgba(255, 100, 255, 0.6)", shadow: "#ff64ff", paths: [[168, 6, 197, 195, 5], [64, 98, 97, 2, 326, 327, 294]] },
            lips: { color: "rgba(255, 50, 80, 0.7)", shadow: "#ff3250", paths: [[61, 185, 40, 39, 37, 0, 267, 269, 270, 409, 291, 146, 91, 181, 84, 17, 314, 405, 321, 375, 291, 61], [78, 191, 80, 81, 82, 13, 312, 311, 310, 415, 308, 324, 318, 402, 317, 14, 87, 178, 88, 95, 78]] }
        };
        for (const zoneName in faceZones) {
            const zone = faceZones[zoneName];
            ctx.strokeStyle = zone.color; ctx.shadowColor = zone.shadow;
            ctx.beginPath();
            zone.paths.forEach(chain => {
                for (let i = 0; i < chain.length; i++) {
                    const index = chain[i];
                    if (landmarks[index]) {
                        const p = display.toFeedback(1 - landmarks[index].x, landmarks[index].y, canvas);
                        if (i === 0) ctx.moveTo(p.x, p.y); else ctx.lineTo(p.x, p.y);
                    }
                }
            });
            ctx.stroke();
        }
        ctx.shadowBlur = 0; ctx.lineWidth = 1;
    }

    // --- INITIALISATION ---
    async setupCamera() {
        const constraints = { video: { width: { ideal: 1280 }, height: { ideal: 720 }, facingMode: "user" } };
        try {
            const stream = await navigator.mediaDevices.getUserMedia(constraints);
            this.video.srcObject = stream;
            return new Promise((resolve) => {
                this.video.onloadedmetadata = () => {
                    this.video.play();
                    this.video.onplaying = () => { this.isReady = true; resolve(); };
                };
            });
        } catch (e) { console.error("❌ ERREUR CAMÉRA :", e); alert("Impossible d'accéder à la webcam."); }
    }

    async initialize() {
        try {
            console.log("⏳ Initialisation Vision IA (MULTIJOUEUR)...");
            const vision = await FilesetResolver.forVisionTasks("../../assets/wasm");
            
            const [hand, pose, face] = await Promise.all([
                HandLandmarker.createFromOptions(vision, { 
                    baseOptions: { modelAssetPath: "../../assets/models/hand_landmarker.task", delegate: "GPU" }, 
                    runningMode: "VIDEO", 
                    numHands: 2, 
                    minHandDetectionConfidence: 0.5 
                }),
                PoseLandmarker.createFromOptions(vision, { 
                    baseOptions: { modelAssetPath: "../../assets/models/pose_landmarker_lite.task", delegate: "GPU" }, 
                    runningMode: "VIDEO", 
                    numPoses: 2, 
                    minPoseDetectionConfidence: 0.5 
                }),
                FaceLandmarker.createFromOptions(vision, { 
                    baseOptions: { modelAssetPath: "../../assets/models/face_landmarker.task", delegate: "GPU" }, 
                    runningMode: "VIDEO", 
                    outputFaceBlendshapes: false, 
                    outputFacialTransformationMatrix: false, 
                    numFaces: 2 
                })
            ]);
            
            this.handLandmarker = hand; 
            this.poseLandmarker = pose; 
            this.faceLandmarker = face;
            
            await this.setupCamera();
            console.log("✅ InputSystem : PRÊT (Mode 2 Joueurs + Ghost 'G' + Legacy Support)");
        } catch (error) { console.error("❌ CRASH InputSystem :", error); }
    }
}