import { Game } from '../core/Game.js';
import { Registry } from '../core/GameRegistry.js';

export class MenuHolo extends Game {
    constructor(game) {
        super(game);
        this.game = game;
        this.id = 'menu_holo';
        this.name = 'MENU PRINCIPAL';
        this.isMenu = true; // Indispensable pour que le Header s'affiche
    }

    enter() {
        console.log("🌌 MENU HOLO: Activation...");
        
        // 1. Config Caméra : On veut voir le joueur en fond
        this.setup({ cameraMode: 'fullscreen', pose: false, face: false, hands: true });
        
        // 2. Nettoyage Interface
        const layer = this.game.display.gameLayer;
        layer.innerHTML = '';
        
        // 3. Création du Conteneur Principal
        const container = document.createElement('div');
        container.className = 'holo-container';
        
        // 4. Titre
        const title = document.createElement('div');
        title.className = 'holo-title';
        title.innerHTML = "JARVIS <span style='color:#00ffff'>ARCADE</span>";
        container.appendChild(title);

        // 5. Grille de Jeux
        const grid = document.createElement('div');
        grid.className = 'holo-grid';

        // 6. Récupération dynamique des jeux
        const games = Registry.getAll();

        games.forEach(g => {
            // On cache le menu lui-même pour ne pas créer une boucle
            if (g.class.prototype.isMenu || g.id === 'menu_holo') return;

            const card = document.createElement('div');
            card.className = 'holo-card interactive'; // 'interactive' active le curseur cercle !
            card.dataset.id = g.id; 

            // Choix de l'icône selon l'ID du jeu
            let icon = "🎮";
            if (g.id.includes('nuts')) icon = "🐿️";
            if (g.id.includes('flappy')) icon = "🦅";
            if (g.id.includes('brick') || g.id.includes('neon')) icon = "🧱";
            if (g.id.includes('fruit')) icon = "⚔️"; // Sabres croisés pour Fruit Blade
            
            card.innerHTML = `
                <div class="holo-icon">${icon}</div>
                <div class="holo-name">${g.name}</div>
                <div class="holo-scanline"></div>
            `;

            // CLIC -> Lancer le jeu
            card.addEventListener('click', () => {
                if(this.game.audio) this.game.audio.playSFX('select');
                
                // Petit effet visuel avant de lancer
                card.style.transform = "scale(0.9)";
                card.style.borderColor = "#fff";
                
                setTimeout(() => {
                    this.game.loadGame(g.id);
                }, 100);
            });

            grid.appendChild(card);
        });

        container.appendChild(grid);
        layer.appendChild(container);
    }

    exit() {
        // Nettoyage propre en sortant
        const layer = this.game.display.gameLayer;
        layer.innerHTML = '';
    }
}

// Enregistrement dans le système
Registry.register('menu_holo', "MENU PRINCIPAL", MenuHolo);